// функция для страниц Контакты
(function(){
	if($('.contacts').length) {
		$('.wrapper').addClass('wrapper--contacts')
	}
})();