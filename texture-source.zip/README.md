Для запуска шаблона нужно выполнить следующие шаги

1. git clone https://github.com/FARCER/gulp4start
2. npm i
3. gulp